/******************************************************************************

Tarea: Implementación de un sistema de gestión de empleados

Descripción: Diseñar y desarrollar un sistema de gestión de empleados en Java utilizando el enfoque de
programación orientada a objetos  en modo consola. 
La aplicación debe permitir a los usuarios agregar empleados, asignarles información como nombre, edad y salario,
y mostrar los detalles de los empleados existentes.

1.Crear una clase Empleado con los atributos privados necesarios, como nombre, edad y salario.

2.Implementar métodos públicos en la clase Empleado para acceder y modificar los atributos, 
como obtener el nombre, establecer la edad o imprimir la información del empleado.

3.Aplicar el encapsulamiento adecuado utilizando modificadores de acceso para proteger los datos de los empleados y
garantizar el acceso controlado a través de los métodos públicos.

4.Crear una clase GestorEmpleados que contenga una lista de objetos Empleado y métodos para realizar operaciones 
como agregar empleados y mostrar los detalles de los empleados existentes.

5.En la clase Main, en el método main, los estudiantes deben crear instancias de GestorEmpleados y probar las 
funcionalidades implementadas, como agregar empleados y mostrar los detalles de los empleados existentes.
*******************************************************************************/


public class Main {
    public static void main(String[] args) {
        GestorEmpleados gestor = new GestorEmpleados(10);  
        
        
        
        // Crear empleados
        Empleado emp1 = new Empleado("Rayo Mqueen", 30, 50000);
        Empleado emp2 = new Empleado("Flash ", 28, 45000);

        // Agregar empleados al gestor
        gestor.agregarEmpleado(emp1);
        gestor.agregarEmpleado(emp2);

        // Mostrar detalles de los empleados
        gestor.mostrarDetallesEmpleados();
    }
}



class Empleado {
    private String nombre;
    private int edad;
    private double salario;

    public Empleado(String nombre, int edad, double salario) {
        this.nombre = nombre;
        this.edad = edad;
        this.salario = salario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getSalario() {
        return salario;
    }

    public void imprimirInformacion() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad);
        System.out.println("Salario: $" + salario);
    }
}

class GestorEmpleados {
    private Empleado[] empleados;
    private int contador;

    public GestorEmpleados(int capacidad) {
        empleados = new Empleado[capacidad];
        contador = 0;
    }

    public void agregarEmpleado(Empleado empleado) {
        if (contador < empleados.length) {
            empleados[contador] = empleado;
            contador++;
        } else {
            System.out.println("No se pueden agregar más empleados. Capacidad máxima alcanzada.");
        }
    }

    public void mostrarDetallesEmpleados() {
        for (int i = 0; i < contador; i++) {
            empleados[i].imprimirInformacion();
            System.out.println("--------------------");
        }
    }
}
